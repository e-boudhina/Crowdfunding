const authJwt = require("./User/authJwt");
const verifySignUp = require("./User/verifySignUp");
module.exports = {
  authJwt,
  verifySignUp
};